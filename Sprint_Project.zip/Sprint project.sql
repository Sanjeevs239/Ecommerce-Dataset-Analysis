CREATE DATABASE sales;
USE sales;
CREATE TABLE customers (
    customer_id VARCHAR(255) PRIMARY KEY,
    customer_zip_code_prefix INT,
    customer_city VARCHAR(255),
    customer_state VARCHAR(10)
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/df_Customers.csv'
INTO TABLE customers
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE order_items (
    order_id VARCHAR(255),
    product_id VARCHAR(255),
    seller_id VARCHAR(255),
    price DECIMAL(10,2),
    shipping_charges DECIMAL(10,2),
    PRIMARY KEY (order_id, product_id, seller_id)
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/df_OrderItems.csv'
INTO TABLE order_items
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

DROP TABLE IF EXISTS orders;

CREATE TABLE orders (
    order_id VARCHAR(255) PRIMARY KEY,
    customer_id VARCHAR(255),
    order_purchase_timestamp DATETIME,
    order_approved_at DATETIME NULL  -- Allow NULL values
);


LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/df_Orders.csv'
INTO TABLE orders
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(order_id, customer_id, order_purchase_timestamp, @order_approved_at)
SET order_approved_at = NULLIF(TRIM(@order_approved_at), '');


CREATE TABLE payments (
    order_id VARCHAR(255),
    payment_sequential INT,
    payment_type VARCHAR(50),
    payment_installments INT,
    payment_value DECIMAL(10,2),
    PRIMARY KEY (order_id, payment_sequential)
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/df_Payments.csv'
INTO TABLE payments
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE product (
    product_id VARCHAR(255),
    product_category_name VARCHAR(255),
    product_weight_g INT,
    product_length_cm INT,
    product_height_cm INT,
    product_width_cm INT
);
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/df_Products.csv'
INTO TABLE product
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(product_id, product_category_name, @product_weight_g, @product_length_cm, @product_height_cm, @product_width_cm)
SET
    product_weight_g = NULLIF(@product_weight_g, ''),
    product_length_cm = NULLIF(@product_length_cm, ''),
    product_height_cm = NULLIF(@product_height_cm, ''),
    product_width_cm = NULLIF(@product_width_cm, '');


# Total Revenue and Average Order Value
SELECT 
    SUM(total_payment) AS total_revenue,  
    AVG(total_price) AS avg_order_value   
FROM (
    SELECT 
        o.order_id, 
        SUM(p.payment_value) AS total_payment,  
        SUM(oi.price) AS total_price            
    FROM orders o
    JOIN payments p ON o.order_id = p.order_id
    JOIN order_items oi ON o.order_id = oi.order_id
    GROUP BY o.order_id
) AS order_summary;

# Revenue by Customer State
SELECT 
    c.customer_state, 
    SUM(oi.price) AS total_revenue
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.customer_state
ORDER BY total_revenue DESC;


# Top 5 Customers by Total Spending
SELECT c.customer_id, c.customer_state, SUM(oi.price) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.customer_state
ORDER BY total_spent DESC
LIMIT 5;


 # New vs. Repeat Customers
SELECT 
    SUM(CASE WHEN order_count = 1 THEN 1 ELSE 0 END) AS new_customers,
    SUM(CASE WHEN order_count > 1 THEN 1 ELSE 0 END) AS repeat_customers
FROM (
    SELECT customer_id, COUNT(order_id) AS order_count
    FROM orders
    GROUP BY customer_id
) AS customer_orders;


# Top 5 Product Categories by Revenue
SELECT 
    p.product_category_name, 
    SUM(pmt.payment_value) AS total_revenue
FROM order_items oi
JOIN product p ON oi.product_id = p.product_id
JOIN payments pmt ON oi.order_id = pmt.order_id
GROUP BY p.product_category_name
ORDER BY total_revenue DESC
LIMIT 5;

# Top 10 States by Total Orders
SELECT c.customer_state, COUNT(o.order_id) AS total_orders
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_state
ORDER BY total_orders DESC
LIMIT 10;

# Transaction Count by Payment Method
SELECT payment_type, COUNT(*) AS total_transactions
FROM payments
GROUP BY payment_type
ORDER BY total_transactions DESC;









